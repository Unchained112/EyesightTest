/* 
 * File:   adc.h
 * Author: 12591
 *
 * Created on August 1, 2021, 8:49 PM
 */

#ifndef ADC_H
#define	ADC_H

void ADC_init();
int read_adc_value();

#endif	/* ADC_H */

