

void delay_sw(unsigned int dl) {
    // 40000  0.5s; 1600  20ms
    int i = dl;
    while (i--) {}
}
