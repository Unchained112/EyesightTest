/* 
 * File:   util.h
 * Author: 12591
 *
 * Created on July 24, 2021, 10:37 PM
 */

#ifndef UTIL_H
#define	UTIL_H

#define INPUT_0 (1 << 6)
#define INPUT_1 (1 << 7)
#define INPUT_2 (1 << 13)
#define OUTPUT_0 (1 << 0)
#define OUTPUT_1 (1 << 1)
#define OUTPUT_2 (1 << 2)

#endif	/* UTIL_H */

